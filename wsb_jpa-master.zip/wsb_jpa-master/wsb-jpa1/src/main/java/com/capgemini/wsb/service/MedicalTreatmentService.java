package com.capgemini.wsb.service;

public interface MedicalTreatmentService {
}