package com.capgemini.wsb.persistence.dao;

import com.capgemini.wsb.persistence.entity.AddressEntity;

public interface AddressDao extends Dao<AddressEntity, Long>
{

}
