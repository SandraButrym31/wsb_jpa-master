package com.capgemini.wsb.persistence.enums;

public enum Specialization {

	SURGEON,
	GP,
	DERMATOLOGIST,
	OCULIST

}
