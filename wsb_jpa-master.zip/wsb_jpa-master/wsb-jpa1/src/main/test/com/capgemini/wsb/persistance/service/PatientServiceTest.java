package com.capgemini.wsb.persistance.service;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.capgemini.wsb.dto.PatientTO;
import com.capgemini.wsb.persistence.dao.PatientDao;
import com.capgemini.wsb.persistence.dao.VisitDao;
import com.capgemini.wsb.persistence.entity.AddressEntity;
import com.capgemini.wsb.persistence.entity.PatientEntity;
import com.capgemini.wsb.persistence.entity.VisitEntity;
import com.capgemini.wsb.service.impl.PatientServiceImpl;
import java.time.LocalDate;
import java.util.List;
import org.assertj.core.api.AssertionsForClassTypes;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
public class PatientServiceTest {

    @Mock
    private PatientDao patientDao;
    @Mock
    private VisitDao visitDao;

    @InjectMocks
    private PatientServiceImpl patientServiceImpl;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        patientServiceImpl = new PatientServiceImpl(patientDao, visitDao);
    }


    @Test
    @Transactional
    public void testDeletePatient() {
        // given
        PatientEntity patientEntity = createPatientEntity();

        // when
        patientServiceImpl.removePatient(patientEntity.getId());

        // then
        verify(patientDao).delete(patientEntity.getId());
    }

    @Test
    @Transactional
    public void findPatientById() {
        // given
        PatientEntity patientEntity = createPatientEntity();
        when(patientDao.findOne(patientEntity.getId())).thenReturn(patientEntity);

        // when
        PatientTO byId = patientServiceImpl.findById(patientEntity.getId());

        // then
        AssertionsForClassTypes.assertThat(byId).isNotNull();
        AssertionsForClassTypes.assertThat(byId.getFirstName()).isEqualTo("Tomasz");
        AssertionsForClassTypes.assertThat(byId.getLastName()).isEqualTo("Nowak");
    }

    private PatientEntity createPatientEntity() {
        PatientEntity patientEntity = new PatientEntity();
        patientEntity.setId(1L);
        patientEntity.setFirstName("Tomasz");
        patientEntity.setLastName("Nowak");
        patientEntity.setDateOfBirth(LocalDate.of(1990, 1, 1));
        patientEntity.setPatientNumber("1564789");
        patientEntity.setEmail("xyz@example.com");
        patientEntity.setAddress(new AddressEntity());
        patientEntity.setVisits(List.of(new VisitEntity()));
        return patientEntity;
    }
}