package com.capgemini.wsb.persistance.dao;

import static org.assertj.core.api.Assertions.assertThat;

import com.capgemini.wsb.persistence.dao.PatientDao;
import com.capgemini.wsb.persistence.entity.PatientEntity;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
public class PatientDaoTest {

    @Autowired
    private PatientDao patientDao;

    @Transactional
    @org.junit.jupiter.api.Test
    public void testShouldFindPatientByLastName() {
        // given
        // when
        List<PatientEntity> patientEntity = patientDao.findPatientByLastName("Davis");
        // then
        assertThat(patientEntity).isNotEmpty();
        assertThat(patientEntity.size()).isEqualTo(3);
        assertThat(patientEntity.get(0).getLastName()).isEqualTo("Davis");
    }

    @Transactional
    @org.junit.jupiter.api.Test
    public void testShouldFindPatientByMoreThanOneVisit(){
        //given
        //when
        List<PatientEntity> patientWithMoreThanXVisits = patientDao.findPatientWithMoreThanXVisits(2L);
        //then
        assertThat(patientWithMoreThanXVisits).isNotEmpty();
        assertThat(patientWithMoreThanXVisits.size()).isEqualTo(1);
    }

    @Transactional
    @Test
    public void testShouldFindPatientsByLikeDescription(){
        //given
        //when
        List<PatientEntity> patientsByLikeDescription = patientDao.findPatientsByLikeDescription("Patient description 1");
        //then
        assertThat(patientsByLikeDescription).isNotEmpty();
        assertThat(patientsByLikeDescription.size()).isEqualTo(2);
    }
}